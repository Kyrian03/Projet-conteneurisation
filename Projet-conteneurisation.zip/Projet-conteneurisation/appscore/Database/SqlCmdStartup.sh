#wait for the SQL Server to start up
#sleep 25
echo "Database preparation :"
echo "  - waiting for sqlserv availability... [$(date "+%d.%m.%Y - %H:%M:%S")]"
while true
 do
  if [[ $(/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P Pass@word -d master -Q "quit" >/dev/null 2>1; echo $?) -eq 0 ]]
   then
    echo "  - sqlserv is now ready to use ! [$(date "+%d.%m.%Y - %H:%M:%S")]"
    break
  fi
  sleep 1
done

#run the setup script to create the DB and the schema in the DB
# 
if [[ $(/opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P Pass@word -d master -Q "use [dotnetgigs.jobs];" | grep "Changed database" >/dev/null 2>1; echo $?) -ne 0 ]]
 then
  echo "  - running the setup script to create the DB and the schema in the DB. [$(date "+%d.%m.%Y - %H:%M:%S")]"
  /opt/mssql-tools/bin/sqlcmd -S localhost -U sa -P Pass@word -d master -i SqlCmdScript.sql -o kub_SqlCmdScript.log
  rm SqlCmdScript.sql >/dev/null 2>1
else
  echo "  - database already configured. [$(date "+%d.%m.%Y - %H:%M:%S")]"
fi

echo "  - End of program. [$(date "+%d.%m.%Y - %H:%M:%S")]"
echo "  - see logs 'kub_SqlCmdScript.log' and 'kub_entrypoint.log' for more details."
echo "  -----------------------------------------------------------------------"