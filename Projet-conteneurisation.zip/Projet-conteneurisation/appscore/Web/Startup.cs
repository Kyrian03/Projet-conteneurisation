﻿
using System;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Http;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Web.Config;
using Web.Services;
//20022026

using System.Threading;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
//using Microsoft.Extensions.DependencyInjection;
using System.IO;

//20022026

namespace Web
{
    public class Startup
    {
        public IContainer ApplicationContainer { get; private set; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();

            //20022026
            // Configure data protection to persist keys to a file system  
            services.AddDataProtection()  
            .SetApplicationName("MyApp")
            .PersistKeysToFileSystem(new DirectoryInfo(@"/DataProtection-Keys/")) // Use a secure, accessible path  
            .SetDefaultKeyLifetime(TimeSpan.FromDays(180)); // Extend key lifetime (optional)  

            // Add antiforgery services (included by default in MVC/Razor Pages)  
            services.AddAntiforgery();  
            //20022026

            var builder = new ContainerBuilder();
            builder.RegisterInstance<IHttpClient>(new StandardHttpClient());
            services.AddTransient<IJobService, JobService>();
            services.AddTransient<IIdentityService, IdentityService>();
            builder.RegisterInstance(Configuration.GetSection("ApiSettings").Get<ApiConfig>());
    

            builder.Populate(services);
            ApplicationContainer = builder.Build();

            //20022026
            return new AutofacServiceProvider(ApplicationContainer);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, IApplicationLifetime appLifetime)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });

            // If you want to dispose of resources that have been resolved in the
            // application container, register for the "ApplicationStopped" event.
            // You can only do this if you have a direct reference to the container,
            // so it won't work with the above ConfigureContainer mechanism.
            appLifetime.ApplicationStopped.Register(() => ApplicationContainer.Dispose());
        }
    }
}
